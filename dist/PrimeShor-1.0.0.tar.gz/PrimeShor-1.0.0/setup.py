from setuptools import setup

setup(
    name="PrimeShor",
    version="1.0.0",
    description="A package to find prime factors of a number and check if it's prime using shor algortihm.",
    author="Bader alotibi",
    packages=[""],
)
